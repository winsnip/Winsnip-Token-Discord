chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getToken") {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            chrome.scripting.executeScript({
                target: { tabId: tabs[0].id },
                func: grabToken
            }, (result) => {
                sendResponse({ success: result[0]?.result ? true : false, token: result[0]?.result });
            });
        });
        return true;
    }
});

function grabToken() {
    return localStorage.getItem("token")?.replace(/"/g, "");
}
