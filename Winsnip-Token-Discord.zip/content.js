(function() {
    try {
        let token = JSON.parse(localStorage.getItem("token"));
        if (token) {
            chrome.runtime.sendMessage({ action: "copyToken", token: token });
        }
    } catch (e) {
        console.error("❌ Error retrieving token:", e);
    }
})();
